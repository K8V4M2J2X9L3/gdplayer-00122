<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto ja04LP4hbNF3Kx7m; BkXQRBn_LBtsy5TJ: $views = new \GDPlayer\Views(); goto A4zDlNBT31Jj5pL1; A4zDlNBT31Jj5pL1: $views->getFileContent(__DIR__ . "\x2f\x76\151\x65\167\163\57\x34\60\x33\56\160\x68\x70"); goto GMAzhG4gWrzdxHa8; K0m2yZXVcf7e7IOH: $userLogin = current_user(); goto gJFYrj296rlHGt7d; ja04LP4hbNF3Kx7m: require_once __DIR__ . "\x2f\x64\145\x66\151\156\x65\x64\56\160\x68\160"; goto K0m2yZXVcf7e7IOH; S46CJBNUWEgKLjeg: session_write_close(); goto BkXQRBn_LBtsy5TJ; gJFYrj296rlHGt7d: if ($userLogin) { goto PVVsCBZ13QvYz6fd; } goto S46CJBNUWEgKLjeg; GMAzhG4gWrzdxHa8: exit; goto ogoEacGV3X2Herou; ogoEacGV3X2Herou: PVVsCBZ13QvYz6fd:
