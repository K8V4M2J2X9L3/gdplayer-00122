<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto edL7NNGCj54rm0zt; mPnUlAEd98Z1m6tx: session_write_close(); goto xiVuO1chYkOij0x_; edL7NNGCj54rm0zt: if (defined("\x42\x41\123\105\x5f\125\x52\x4c")) { goto FIX7E5TaMGBhUZpQ; } goto mPnUlAEd98Z1m6tx; cnJXM8p1rdJdIoyq: $_POST = []; goto Q8S90s0xkQrlfdW0; ZRXI66_wnCVlRrTm: if (!(!$security->mekNgumbe() && (isset($_SERVER["\122\105\x51\x55\x45\123\x54\x5f\x55\x52\x49"]) && strpos($_SERVER["\x52\105\121\125\x45\123\124\x5f\125\122\111"], "\57\x6c\x6f\x67\x69\156") === false) && (isset($_POST["\x61\143\164\x69\x6f\156"]) && sanitize_html($_POST["\141\143\x74\151\157\156"]) !== "\x73\141\x76\x65\x4c\151\143\x65\x6e\x73\x65"))) { goto Zrg5IjD7lN_6tOe3; } goto kBysEU1GnRSYG4RK; xiVuO1chYkOij0x_: exit("\x41\x63\x63\x65\x73\x73\x20\144\x65\156\151\145\x64"); goto VI69pX4GAFr4nWSy; VI69pX4GAFr4nWSy: FIX7E5TaMGBhUZpQ: goto Y1jAj36j9DDBWwZN; Y1jAj36j9DDBWwZN: $security = new \GDPlayer\Security(); goto ZRXI66_wnCVlRrTm; kBysEU1GnRSYG4RK: session_write_close(); goto cnJXM8p1rdJdIoyq; Q8S90s0xkQrlfdW0: Zrg5IjD7lN_6tOe3:
