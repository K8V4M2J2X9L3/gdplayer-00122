<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:31              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class goodstream extends \GDPlayer\YetiShare { public function __construct($id, $dl, $hostname) { goto AUNzGv901Onx95cp; sLABVw9mDp_gnNCg: $this->getDOMTitle("\150\x74\x74\x70\x73\x3a\57\57\147\157\x6f\144\163\164\162\145\141\x6d\x2e\x75\156\157\x2f" . $this->id, "\150\x31\56\150\x33"); goto F8dl9WLGH4jjmCon; AUNzGv901Onx95cp: session_write_close(); goto bsY8eh0NEXUBiz6C; bsY8eh0NEXUBiz6C: parent::__construct($id, $dl, $hostname); goto sLABVw9mDp_gnNCg; F8dl9WLGH4jjmCon: } public function __destruct() { session_write_close(); parent::__destruct(); } }
