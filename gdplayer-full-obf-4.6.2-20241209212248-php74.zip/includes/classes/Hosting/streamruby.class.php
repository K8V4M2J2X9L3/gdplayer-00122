<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class streamruby extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto pN05ptb85JS0I_jO; pN05ptb85JS0I_jO: session_write_close(); goto Au_vWASGbi80Huc_; xykZ9EF96pZr5iFy: $this->getDOMTitle($this->url); goto eRKv_0OlQxsQkA0S; Au_vWASGbi80Huc_: parent::__construct($id, $dl, $hostname); goto xykZ9EF96pZr5iFy; eRKv_0OlQxsQkA0S: } public function __destruct() { session_write_close(); parent::__destruct(); } }
