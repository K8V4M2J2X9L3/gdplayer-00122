<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class supervideo extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto Id7v58XoJGU6K0Ss; Id7v58XoJGU6K0Ss: session_write_close(); goto URfwDQMGv3h2XZhu; URfwDQMGv3h2XZhu: parent::__construct($id, $dl, $hostname); goto dAN4bzuSWjSPDbzX; dAN4bzuSWjSPDbzX: $this->getDOMTitle($this->url, "\x68\x31\56\x64\x6f\167\156\x6c\157\x61\144\137\x5f\x74\x69\164\154\145"); goto fAgZiwtdnrcuc4Gd; fAgZiwtdnrcuc4Gd: } public function __destruct() { session_write_close(); parent::__destruct(); } }
