<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:31              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class mymailru extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto Fhy9JvoQ8ity7y1W; Fhy9JvoQ8ity7y1W: session_write_close(); goto EKmNSDa8aaCAv4jd; owpLhamjbIVcF2mb: $this->getCFSources(); goto l57UmI5zzX1tjNtx; EKmNSDa8aaCAv4jd: parent::__construct($id, $dl, $hostname); goto owpLhamjbIVcF2mb; l57UmI5zzX1tjNtx: } public function __destruct() { session_write_close(); parent::__destruct(); } }
