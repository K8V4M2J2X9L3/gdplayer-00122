<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class vidtube extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto lDiv9IXIgvgks49g; gbfvsRicTQANnDJr: parent::__construct($id, $dl, $hostname); goto ILMYbAIDylol4EFs; ILMYbAIDylol4EFs: $this->getDOMTitle("\x68\164\x74\160\163\x3a\x2f\x2f\166\151\x64\x74\165\x62\145\56\x6f\x6e\x65\57" . $this->id, "\150\61\56\x68\x35"); goto kK1KdK5kxhBf5a0s; lDiv9IXIgvgks49g: session_write_close(); goto gbfvsRicTQANnDJr; kK1KdK5kxhBf5a0s: } public function __destruct() { session_write_close(); parent::__destruct(); } }
