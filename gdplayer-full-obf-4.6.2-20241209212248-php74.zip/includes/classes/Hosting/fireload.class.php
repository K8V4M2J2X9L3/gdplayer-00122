<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:31              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class fireload extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto BSKgolU3MoBGaq7Z; nJpssVK_30KWeWgs: sleep(6); goto nx4VGJjYR8zjkx9z; BSKgolU3MoBGaq7Z: session_write_close(); goto vOYcjtEusJaPlv5m; nMM0HHLcJqf6Fvh_: session_write_close(); goto nJpssVK_30KWeWgs; dEbidb_P8Y7SupBH: IIURGIzcACoVXpni: goto XS5uFoyFud8n9bLR; vOYcjtEusJaPlv5m: parent::__construct($id, $dl, $hostname); goto pcRp3haol4WO1YZE; pcRp3haol4WO1YZE: $this->getCFSources(); goto cWKxJMIUpSyJ5lg8; nx4VGJjYR8zjkx9z: $this->sources = $this->getNewSources($this->sources); goto dEbidb_P8Y7SupBH; cWKxJMIUpSyJ5lg8: if (empty($this->sources)) { goto IIURGIzcACoVXpni; } goto nMM0HHLcJqf6Fvh_; XS5uFoyFud8n9bLR: } public function __destruct() { session_write_close(); parent::__destruct(); } }
