<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class vidoza extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto Ue0KlS1lAq5g5a4Z; QAqlaC3HAkVXsl2C: $this->url = $this->baseURL . "\x65\155\x62\145\144\x2d" . $id . "\x2e\150\x74\155\x6c"; goto ecwQ7JQEytNyvUa3; I2SmYn4aIXt8S1qo: $this->baseURL = "\150\x74\164\x70\163\72\57\x2f\x76\151\144\x6f\172\x61\x2e\x6e\145\x74\x2f"; goto QAqlaC3HAkVXsl2C; ecwQ7JQEytNyvUa3: parent::__construct($id, $dl, $hostname); goto snXptMkOzybqH8jD; Ue0KlS1lAq5g5a4Z: session_write_close(); goto I2SmYn4aIXt8S1qo; snXptMkOzybqH8jD: } public function __destruct() { session_write_close(); parent::__destruct(); } }
