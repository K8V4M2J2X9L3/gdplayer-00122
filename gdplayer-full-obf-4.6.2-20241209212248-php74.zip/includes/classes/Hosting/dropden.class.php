<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:31              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class dropden extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto isVFwBkOP3So6IRb; isVFwBkOP3So6IRb: session_write_close(); goto yyESJTIfHulJoNkO; yyESJTIfHulJoNkO: parent::__construct($id, $dl, $hostname); goto pYnshTQYqRgUJLFy; pYnshTQYqRgUJLFy: $this->getCFSources(); goto pchk6obNEIJmXxag; pchk6obNEIJmXxag: } public function __destruct() { session_write_close(); parent::__destruct(); } }
