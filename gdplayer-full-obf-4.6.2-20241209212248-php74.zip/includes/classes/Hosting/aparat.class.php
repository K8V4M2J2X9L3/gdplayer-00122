<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:30              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class aparat extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto XSNT7FXjlyOx1LtA; XSNT7FXjlyOx1LtA: session_write_close(); goto cJdR1fEYelAAhsUG; H_2nfD5wPULfsuTc: $this->getCFSources(); goto va0q1xE9Pcbtk1Uu; cJdR1fEYelAAhsUG: parent::__construct($id, $dl, $hostname); goto H_2nfD5wPULfsuTc; va0q1xE9Pcbtk1Uu: } public function __destruct() { session_write_close(); parent::__destruct(); } }
