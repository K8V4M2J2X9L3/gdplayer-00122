<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class upstream extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto QkZM5a3xEsezmIe1; RaC7kUI1q1Y_Fbv3: parent::__construct($id, $dl, $hostname); goto JPqOq9j2TKTM1Wrh; JPqOq9j2TKTM1Wrh: $this->getDOMTitle($this->url, "\x68\x31\x2e\164\145\170\x74\x2d\x77\150\x69\x74\x65"); goto RhFZOlGgaLAPURz0; QkZM5a3xEsezmIe1: session_write_close(); goto RaC7kUI1q1Y_Fbv3; RhFZOlGgaLAPURz0: } public function __destruct() { session_write_close(); parent::__destruct(); } }
