<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:31              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class krakenfiles extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto tWycmUyIEODjVE7J; bM3jHlPa1RX87T58: parent::__construct($id, $dl, $hostname); goto OFeTX8Vb8iVZW7Wu; zDh0qL2Qmp2yfB02: if (empty($this->sources)) { goto DQ_ZYJdd_y0mbFmw; } goto rerePvdiN5QVgj4a; f_gs2mSEL7icZeCJ: DQ_ZYJdd_y0mbFmw: goto dOHWTs546xuEfyaO; OFeTX8Vb8iVZW7Wu: $this->getDOMTitle($this->url, "\56\143\x6f\x69\x6e\55\x69\156\x66\x6f\40\x68\65"); goto zDh0qL2Qmp2yfB02; tWycmUyIEODjVE7J: session_write_close(); goto bM3jHlPa1RX87T58; rerePvdiN5QVgj4a: session_write_close(); goto YQ67YFbiYa0WNz1t; YQ67YFbiYa0WNz1t: $this->sources = array_map(function ($dt) { goto rcFk6d5pTS1QAcze; le2iAFBebOQW3Toj: return $dt; goto LR3_mngmhPbveVUB; pV53bevti1hNnOdv: $dt["\146\x69\x6c\145"] = "\x68\164\164\x70\163\x3a" . htmlspecialchars_decode($dt["\x66\x69\154\145"]); goto le2iAFBebOQW3Toj; rcFk6d5pTS1QAcze: session_write_close(); goto pV53bevti1hNnOdv; LR3_mngmhPbveVUB: }, $this->sources); goto f_gs2mSEL7icZeCJ; dOHWTs546xuEfyaO: } public function __destruct() { session_write_close(); parent::__destruct(); } }
