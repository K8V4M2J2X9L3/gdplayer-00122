<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class streamff extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto QJoU4p20a_YOlNnC; veU681gAj72Ah3jc: $this->getCFSources(); goto WkTdXE11GfqAMZX9; QJoU4p20a_YOlNnC: session_write_close(); goto ni7EU2yAjsJr_hlY; ni7EU2yAjsJr_hlY: parent::__construct($id, $dl, $hostname); goto veU681gAj72Ah3jc; WkTdXE11GfqAMZX9: } public function __destruct() { session_write_close(); parent::__destruct(); } }
