<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class streamable extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto F0lZt0ansITet9cZ; kAr0kRgPWf7ZQb8d: $this->getCFSources(); goto ZVBKhcZiliaG8BU1; r0AFw5xeP10W8Nbc: parent::__construct($id, $dl, $hostname); goto kAr0kRgPWf7ZQb8d; F0lZt0ansITet9cZ: session_write_close(); goto r0AFw5xeP10W8Nbc; ZVBKhcZiliaG8BU1: } public function __destruct() { session_write_close(); parent::__destruct(); } }
