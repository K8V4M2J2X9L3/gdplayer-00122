<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:31              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class filemail extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto qSvKXw6TPWU6cKf6; ZUxKadJMZJ4JdCqz: parent::__construct($id, $dl, $hostname); goto zzB6rN0EncpjIXqM; zzB6rN0EncpjIXqM: $this->getCFSources(); goto N2jfjC9GTUdmpMV1; qSvKXw6TPWU6cKf6: session_write_close(); goto ZUxKadJMZJ4JdCqz; N2jfjC9GTUdmpMV1: } public function __destruct() { session_write_close(); parent::__destruct(); } }
