<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class rumble extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto OJ5JYwmWzCa2pvK3; iwCBvWIhNpekov1P: $this->baseURL = "\150\x74\164\x70\163\x3a\57\x2f\x72\165\155\142\x6c\145\x2e\x63\157\x6d\x2f"; goto y6qZGiv3WjKn3aLH; y6qZGiv3WjKn3aLH: parent::__construct($id, $dl, $hostname); goto X2IEV3GdYcYPapb2; X2IEV3GdYcYPapb2: $this->getCFSources(); goto hWC1yfNn8LPwy32J; OJ5JYwmWzCa2pvK3: session_write_close(); goto iwCBvWIhNpekov1P; hWC1yfNn8LPwy32J: } public function __destruct() { session_write_close(); parent::__destruct(); } }
