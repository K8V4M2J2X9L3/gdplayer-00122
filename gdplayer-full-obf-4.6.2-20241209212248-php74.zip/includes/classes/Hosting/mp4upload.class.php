<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:31              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class mp4upload extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto aukNAS8SHHlG6wzm; aukNAS8SHHlG6wzm: session_write_close(); goto rM9Y0KWD0OQCWupf; rM9Y0KWD0OQCWupf: parent::__construct($id, $dl, $hostname); goto XaUsGcG0vI_9ICTK; XaUsGcG0vI_9ICTK: $this->getDOMTitle($this->url, "\56\146\x69\154\145\55\x69\x6e\146\157\40\56\x6e\x61\x6d\x65\x20\x68\64"); goto UKhSave3STfzUwhO; UKhSave3STfzUwhO: } public function __destruct() { session_write_close(); parent::__destruct(); } }
