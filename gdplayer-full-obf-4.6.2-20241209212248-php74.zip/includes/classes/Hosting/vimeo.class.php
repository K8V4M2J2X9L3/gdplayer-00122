<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class vimeo extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto J1z0WmxaGP02q2yO; J1z0WmxaGP02q2yO: session_write_close(); goto RNvPQhrXsigkuF7G; RNvPQhrXsigkuF7G: $this->baseURL = "\x68\x74\x74\x70\163\72\x2f\57\x76\151\155\x65\157\56\143\157\x6d\x2f"; goto c7o8KxNKw1w2Stjg; c7o8KxNKw1w2Stjg: parent::__construct($id, $dl, $hostname); goto KuOuH_NEiuU6Nt4G; KuOuH_NEiuU6Nt4G: $this->getCFSources(); goto E0ATrQJ7D0ZrDBe8; E0ATrQJ7D0ZrDBe8: } public function __destruct() { session_write_close(); parent::__destruct(); } }
