<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:31              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class filelions extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto G51ymHLMZ6srF5Hc; G51ymHLMZ6srF5Hc: session_write_close(); goto WyHVPd3twWYXNjXs; vJfrNH48fY1ASO0Z: parent::__construct($id, $dl, $hostname); goto S4GCQIPzbvF84cpr; znFnseLPL6iCD4UX: $this->url = $this->baseURL . "\166\57" . $id; goto vJfrNH48fY1ASO0Z; WyHVPd3twWYXNjXs: $this->baseURL = "\150\x74\x74\x70\x73\72\57\57\x76\x69\x64\x68\151\x64\x65\160\162\x6f\x2e\x63\157\x6d\x2f"; goto znFnseLPL6iCD4UX; S4GCQIPzbvF84cpr: $this->getDOMTitle($this->baseURL . "\146\57" . $this->id, "\150\x31\x2e\150\x34"); goto gnFH2UvRqvhvShik; gnFH2UvRqvhvShik: } public function __destruct() { session_write_close(); parent::__destruct(); } }
