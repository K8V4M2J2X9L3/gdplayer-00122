<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class tiktok extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto TgkUYOrG95RADOyj; TgkUYOrG95RADOyj: session_write_close(); goto FgFO2IyFhLUITpm0; CzsbPzC1H4Iygtr4: session_write_close(); goto LfFYTek8YMdjHseW; sW2n6rMrkOS3Owdp: session_write_close(); goto IW5M39QVHYTKszA7; XT2FWvXlBHknHSvQ: mu4WLvI1Xg5cV62c: goto vTN18DOHYctCZCnL; UVGfknRJ1SaWP6Ik: LY91aZeWuU4848_2: goto GEaUB02YoByUKLfr; TmshqxU6ugCC23tU: $this->getCFSources(); goto tigVo4AabjCn323G; IW5M39QVHYTKszA7: $this->image = strtr(rawurldecode($this->image), ["\x5c\165\x30\60\x32\106" => "\57"]); goto UVGfknRJ1SaWP6Ik; FgFO2IyFhLUITpm0: parent::__construct($id, $dl, $hostname); goto TmshqxU6ugCC23tU; vTN18DOHYctCZCnL: if (empty($this->image)) { goto LY91aZeWuU4848_2; } goto sW2n6rMrkOS3Owdp; tigVo4AabjCn323G: if (empty($this->sources[0]["\x66\151\154\x65"])) { goto mu4WLvI1Xg5cV62c; } goto CzsbPzC1H4Iygtr4; LfFYTek8YMdjHseW: $this->sources[0]["\146\151\154\x65"] = strtr(rawurldecode($this->sources[0]["\146\x69\x6c\145"]), ["\134\x75\x30\60\x32\x46" => "\x2f"]); goto XT2FWvXlBHknHSvQ; GEaUB02YoByUKLfr: } public function __destruct() { session_write_close(); parent::__destruct(); } }
