<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:31              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class mixdrop extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto obg6JGHAaN_LPoTN; GZL7ZMx4mYCBTT1f: $this->url = "\x68\164\164\x70\x73\x3a\57\x2f\x6d\x69\170\x64\x72\x6f\x70\x2e\160\x73\57\145\57" . $id; goto vqH7z3VP38y_aYl5; pIcF9dnpHjgTEUmU: $this->getDOMTitle(strtr($this->url, ["\57\x65\57" => "\x2f\146\x2f"])); goto xYJ3wy5midLe2p7h; obg6JGHAaN_LPoTN: session_write_close(); goto GZL7ZMx4mYCBTT1f; vqH7z3VP38y_aYl5: parent::__construct($id, $dl, $hostname); goto pIcF9dnpHjgTEUmU; xYJ3wy5midLe2p7h: } public function __destruct() { session_write_close(); parent::__destruct(); } }
