<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class uploady extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto rPMfTiBJESynr6Rm; rPMfTiBJESynr6Rm: session_write_close(); goto kpiGMQIJB8IHaQ08; AFVcUMuPEkYkS8lx: $this->getDOMTitle($this->url); goto xFXvuIxg5HHEDu17; kpiGMQIJB8IHaQ08: parent::__construct($id, $dl, $hostname); goto AFVcUMuPEkYkS8lx; xFXvuIxg5HHEDu17: } public function __destruct() { session_write_close(); parent::__destruct(); } }
