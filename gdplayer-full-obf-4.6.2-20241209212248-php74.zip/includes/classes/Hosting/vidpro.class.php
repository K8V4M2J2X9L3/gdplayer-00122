<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class vidpro extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto YyR5P0pF04fad0_A; C57ddSBP7NNeu12P: $this->url = $this->baseURL . "\145\x6d\x62\145\x64\55" . $id . "\56\150\x74\155\x6c"; goto tCxjw0soMj2NvrCt; sIFsiNhTWJ0TLXfh: $this->getDOMTitle($this->baseURL . $id); goto WWCKzu5yyMxcTyHW; hOGZpKwSIiXnmur1: $this->baseURL = "\x68\x74\x74\160\163\x3a\57\57\166\151\144\160\x72\x6f\x2e\x6e\x65\164\57"; goto C57ddSBP7NNeu12P; YyR5P0pF04fad0_A: session_write_close(); goto hOGZpKwSIiXnmur1; tCxjw0soMj2NvrCt: parent::__construct($id, $dl, $hostname); goto sIFsiNhTWJ0TLXfh; WWCKzu5yyMxcTyHW: } public function __destruct() { session_write_close(); parent::__destruct(); } }
