<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class vidhide extends \GDPlayer\Hosting\filelions { public function __construct($id, $dl, $hostname) { goto BCepO6bAXkslV7Ik; V9Cr7djaSIRuxl9m: $this->getDOMTitle($this->baseURL . "\146\57" . $this->id, "\x68\x31\56\150\64"); goto SJfhB7xF5tyTwvtL; R4kCbIvbeS6ZAfMW: $this->url = $this->baseURL . "\x76\57" . $id; goto U8VapOCEHBlTa1yZ; VlkXplsTPFQGAKNt: $this->baseURL = "\x68\164\164\160\x73\72\x2f\57\x76\x69\x64\x68\151\x64\145\x70\x72\x6f\56\x63\x6f\x6d\x2f"; goto R4kCbIvbeS6ZAfMW; U8VapOCEHBlTa1yZ: parent::__construct($id, $dl, $hostname); goto V9Cr7djaSIRuxl9m; BCepO6bAXkslV7Ik: session_write_close(); goto VlkXplsTPFQGAKNt; SJfhB7xF5tyTwvtL: } public function __destruct() { session_write_close(); parent::__destruct(); } }
