<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:30              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class archive extends \GDPlayer\CoreExtractor { public function __construct($id, $dl, $hostname) { goto Z2_r_6Vo1dfydv_t; LTKP6UyOqKx4opJC: $this->getCFSources(); goto blJpTQ9K9t61Xk_k; CFJfsOfKuuZTauTL: parent::__construct($id, $dl, $hostname); goto LTKP6UyOqKx4opJC; Z2_r_6Vo1dfydv_t: session_write_close(); goto CFJfsOfKuuZTauTL; blJpTQ9K9t61Xk_k: } public function __destruct() { session_write_close(); parent::__destruct(); } }
