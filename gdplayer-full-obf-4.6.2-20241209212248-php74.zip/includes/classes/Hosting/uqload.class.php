<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class uqload extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto XD3vur4nYO6tSqWO; HgaiIMHdDAAZzSws: parent::__construct($id, $dl, $hostname); goto im9q1b0UpNv2owak; ioMlRm0cewPJtYOM: $this->baseURL = "\x68\x74\164\x70\x73\72\x2f\57\165\x71\154\x6f\141\x64\x2e\x77\163\x2f"; goto h0rSDkvl_kdd3eNs; XD3vur4nYO6tSqWO: session_write_close(); goto ioMlRm0cewPJtYOM; h0rSDkvl_kdd3eNs: $this->url = $this->baseURL . "\x65\155\142\x65\x64\55" . $id . "\x2e\150\164\155\x6c"; goto HgaiIMHdDAAZzSws; im9q1b0UpNv2owak: } public function __destruct() { session_write_close(); parent::__destruct(); } }
