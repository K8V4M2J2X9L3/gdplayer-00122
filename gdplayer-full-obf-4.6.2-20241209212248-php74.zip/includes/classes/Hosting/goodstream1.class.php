<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:31              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class goodstream1 extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto MPTrXEMy9FznwZMx; PqiOngW59EfeeaW1: parent::__construct($id, $dl, $hostname); goto dgJmN6r2wVNohZo2; MPTrXEMy9FznwZMx: session_write_close(); goto PqiOngW59EfeeaW1; dgJmN6r2wVNohZo2: $this->getDOMTitle("\150\164\164\x70\163\72\57\57\147\157\157\x64\163\x74\162\x65\x61\155\x2e\x6f\x6e\x65\57" . $this->id, "\x68\x31\56\150\65"); goto jubfOaGeiWdWVE_a; jubfOaGeiWdWVE_a: } public function __destruct() { session_write_close(); parent::__destruct(); } }
