<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:32              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class vidlook extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto IpOvAkNRMZ5Qkemw; LGmCAJGbBB105Lav: $this->url = $this->baseURL . "\x65\x6d\x62\x65\144\x2d" . $id . "\56\150\164\x6d\x6c"; goto kG9MUeCZwHN9CWkn; IEy4oc3nip5j45pC: $this->getDOMTitle($this->baseURL . $id); goto Jiq4J1GWyKgO9y1H; kG9MUeCZwHN9CWkn: parent::__construct($id, $dl, $hostname); goto IEy4oc3nip5j45pC; VwswSqQBEaAFaGX2: $this->baseURL = "\150\x74\164\x70\x73\72\57\57\x76\x69\144\x6c\157\157\153\x2e\156\x65\x74\x2f"; goto LGmCAJGbBB105Lav; IpOvAkNRMZ5Qkemw: session_write_close(); goto VwswSqQBEaAFaGX2; Jiq4J1GWyKgO9y1H: } public function __destruct() { session_write_close(); parent::__destruct(); } }
