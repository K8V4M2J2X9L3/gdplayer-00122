<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:34:31              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Hosting; class fileupload extends \GDPlayer\XVFSParser { public function __construct($id, $dl, $hostname) { goto UmZgdi6ZxlDGkBF0; Sj9apmOslW7JIPUe: $this->baseURL = "\150\164\x74\x70\x73\x3a\x2f\57\167\167\167\56\146\x69\154\145\55\x75\160\x6c\x6f\x61\x64\56\x6f\x72\x67\57"; goto O4VRFQBHN8H0eYt4; gEb9h7FcOCnHWsBe: parent::__construct($id, $dl, $hostname); goto x4mA2SRJ1BrcyG5A; x4mA2SRJ1BrcyG5A: $this->getDOMTitle($this->baseURL . $this->id, "\x68\61"); goto KDz8Ek360WDRNTvn; O4VRFQBHN8H0eYt4: $this->url = $this->baseURL . "\145\x6d\x62\x65\144\55" . $id . "\56\x68\x74\155\154"; goto gEb9h7FcOCnHWsBe; UmZgdi6ZxlDGkBF0: session_write_close(); goto Sj9apmOslW7JIPUe; KDz8Ek360WDRNTvn: } public function __destruct() { session_write_close(); parent::__destruct(); } }
