<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class GDriveDuplicate extends \GDPlayer\Model { protected $table = "\x74\142\x5f\x67\x64\162\x69\166\x65\x5f\144\165\x70\x6c\151\143\x61\164\145"; protected $fields = ["\x69\x64", "\147\144\162\151\166\145\x5f\151\144", "\x67\144\x72\x69\x76\145\137\x65\x6d\141\x69\154", "\164\x69\164\154\x65", "\144\x65\x73\143", "\x66\x69\x6c\145\x53\151\172\x65", "\155\144\65\x43\150\x65\143\x6b\x73\165\x6d", "\163\150\141\61\x43\x68\x65\x63\x6b\x73\165\155", "\x73\x68\141\x32\x35\x36\103\x68\x65\143\153\x73\x75\x6d"]; protected $primaryKey = "\x69\x64"; public function __construct() { session_write_close(); parent::__construct(); } public function getUpdateQueries() { session_write_close(); return []; } public function __destruct() { session_write_close(); parent::__destruct(); } }
