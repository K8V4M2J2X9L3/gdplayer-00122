<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class vwSubtitleManager extends \GDPlayer\Model { protected $table = "\x76\x77\137\163\x75\x62\x74\x69\x74\154\145\x5f\155\x61\x6e\x61\x67\x65\162"; protected $fields = ["\x69\x64", "\146\151\x6c\145\137\156\141\155\x65", "\154\141\156\x67\165\x61\x67\145", "\150\x6f\x73\x74", "\141\x64\144\x65\x64", "\x75\x70\144\x61\164\x65\144", "\x75\151\x64", "\x6e\141\x6d\x65"]; protected $primaryKey = "\151\144"; public function __construct() { session_write_close(); parent::__construct(); } public function getUpdateQueries() { session_write_close(); return []; } public function __destruct() { session_write_close(); parent::__destruct(); } }
