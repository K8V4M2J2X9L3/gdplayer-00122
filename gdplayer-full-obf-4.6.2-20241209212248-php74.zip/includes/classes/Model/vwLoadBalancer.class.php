<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class vwLoadBalancer extends \GDPlayer\Model { protected $table = "\166\x77\x5f\x6c\157\141\x64\x62\141\154\141\156\x63\x65\162\x73"; protected $fields = ["\151\x64", "\156\x61\x6d\145", "\154\x69\x6e\153", "\160\165\x62\154\x69\x63", "\x73\x74\x61\164\165\163", "\141\144\144\145\x64", "\x75\160\x64\141\164\x65\x64", "\144\x69\163\141\154\x6c\157\167\x5f\x68\157\163\164\x73", "\144\151\163\141\154\x6c\x6f\167\x5f\x63\157\156\x74\151\156\x65\x6e\164", "\143\157\x6e\x6e\x65\x63\164\x69\x6f\x6e\x73", "\160\x6c\141\171\142\x61\143\x6b\163"]; protected $primaryKey = "\x69\144"; public function __construct() { session_write_close(); parent::__construct(); } public function getUpdateQueries() { session_write_close(); return []; } public function __destruct() { session_write_close(); parent::__destruct(); } }
