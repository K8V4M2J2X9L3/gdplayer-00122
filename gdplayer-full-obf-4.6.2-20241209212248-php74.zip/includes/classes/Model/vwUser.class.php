<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class vwUser extends \GDPlayer\Model { protected $table = "\166\167\137\165\163\145\x72\x73"; protected $fields = ["\x69\144", "\156\141\155\145", "\x75\163\x65\162", "\x65\155\x61\151\154", "\163\x74\x61\x74\165\x73", "\141\144\144\x65\144", "\165\160\x64\x61\164\x65\x64", "\x72\157\x6c\145", "\166\151\x64\x65\157\x73"]; protected $primaryKey = "\151\144"; public function __construct() { session_write_close(); parent::__construct(); } public function getUpdateQueries() { session_write_close(); return []; } public function __destruct() { session_write_close(); parent::__destruct(); } }
