<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class vwVideo extends \GDPlayer\Model { protected $table = "\x76\167\x5f\x76\x69\x64\145\157\163"; protected $fields = ["\x69\x64", "\x74\151\x74\154\x65", "\x68\157\x73\164", "\150\x6f\163\164\137\x69\x64", "\x73\164\x61\x74\165\x73", "\141\144\144\145\144", "\165\160\x64\141\164\x65\144", "\x64\x6d\143\x61", "\x76\151\145\x77\x73", "\x6e\x61\x6d\145", "\165\x69\x64", "\160\157\163\164\145\162"]; protected $primaryKey = "\151\144"; public function __construct() { session_write_close(); parent::__construct(); } public function getUpdateQueries() { session_write_close(); return []; } public function __destruct() { session_write_close(); parent::__destruct(); } }
