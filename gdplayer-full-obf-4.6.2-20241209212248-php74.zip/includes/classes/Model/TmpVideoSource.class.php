<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Model; class TmpVideoSource extends \GDPlayer\Model { protected $table = "\164\142\x5f\164\x6d\160\137\166\151\144\145\157\x73\137\163\157\x75\x72\x63\145\163"; protected $fields = ["\x69\x64", "\x68\x6f\x73\x74", "\x68\157\x73\164\137\151\144", "\147\144\x72\151\166\145\x5f\145\155\x61\151\x6c"]; protected $primaryKey = "\x69\144"; public function __construct() { session_write_close(); parent::__construct(); } public function getUpdateQueries() { session_write_close(); return []; } public function __destruct() { session_write_close(); parent::__destruct(); } }
