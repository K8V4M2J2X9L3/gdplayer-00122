<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer; class Views extends \GDPlayer\HTML { public function getFileContent(string $file = '') { goto cv0YECScfd0aHdSW; xqNTcbGl3MWpdTnD: require_once $file; goto ocDbJwZYKMmmsV5g; cv0YECScfd0aHdSW: session_write_close(); goto xqNTcbGl3MWpdTnD; ocDbJwZYKMmmsV5g: exit; goto eB0Vi1pzoBp7O9Yo; eB0Vi1pzoBp7O9Yo: } }
