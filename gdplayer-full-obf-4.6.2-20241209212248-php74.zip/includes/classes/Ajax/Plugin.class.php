<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-04 07:46:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer\Ajax; class Plugin extends \GDPlayer\Ajax { public function __construct() { session_write_close(); parent::__construct(); } }
