<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer; class ytdlpBridge extends \GDPlayer\CoreHelper { public function __construct(string $url = null, bool $dl = false, string $hostname = "\x79\164\x64\154\x70") { goto y5uGCqh832bASbYb; aD9dUzwNzF3vwbdb: session_write_close(); goto nCXYYzD6S4fSFJ4_; C3rfUOzRO0hqx1ae: $this->title = $ytdlp->getTitle(); goto jDZmbZRd5maK9k3Y; wQ8C_f9kTcAIQlGk: $this->status = $ytdlp->getStatus(); goto rEOiwB0VwvN8rFDt; hZoYl2vZlRG9jOLr: $this->tracks = $ytdlp->getTracks(); goto EDMw4S_6vVq1zV01; WNxTtwkFF7HG9sEK: if (!class_exists("\x47\x44\120\154\141\171\145\162\x5c\110\157\x73\164\151\x6e\x67\x5c\x79\x74\144\154\160")) { goto mCVuYs8dbp3iyIh9; } goto aD9dUzwNzF3vwbdb; EDMw4S_6vVq1zV01: $this->referer = $ytdlp->getReferer(); goto wQ8C_f9kTcAIQlGk; jDZmbZRd5maK9k3Y: $this->image = $ytdlp->getImage(); goto hZoYl2vZlRG9jOLr; nCXYYzD6S4fSFJ4_: $ytdlp = new \GDPlayer\Hosting\ytdlp($url, $dl, $hostname); goto kmdkOSv3ZVf0mO6z; kmdkOSv3ZVf0mO6z: $this->sources = $ytdlp->getSources(); goto C3rfUOzRO0hqx1ae; rEOiwB0VwvN8rFDt: mCVuYs8dbp3iyIh9: goto yFTcoPfDutMfgBUr; y5uGCqh832bASbYb: session_write_close(); goto WNxTtwkFF7HG9sEK; yFTcoPfDutMfgBUr: } }
