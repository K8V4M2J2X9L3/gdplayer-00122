<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 namespace GDPlayer; class VideoPlayer extends \GDPlayer\StreamHelper { public function __construct(string $vHost = '', string $vID = '', string $url = '') { goto JjZQJdwDbUBLvrRm; RWC330WaPzv38gwI: parent::__construct($vHost, $vID, $url); goto DviE1xo8RlwlRwOQ; dISnlEJOoeBQyRe3: $this->isMP4 = true; goto RWC330WaPzv38gwI; JjZQJdwDbUBLvrRm: session_write_close(); goto dISnlEJOoeBQyRe3; DviE1xo8RlwlRwOQ: } public function __destruct() { session_write_close(); parent::__destruct(); } }
