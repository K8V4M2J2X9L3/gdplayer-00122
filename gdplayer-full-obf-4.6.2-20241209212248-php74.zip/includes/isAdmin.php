<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto vOnmYeonpEb1atRZ; vOnmYeonpEb1atRZ: require_once __DIR__ . "\x2f\x64\x65\x66\x69\156\145\144\x2e\160\150\160"; goto M0CRM5wVEMLhmJNS; ApWZPPA43u6PsxBP: exit; goto RmE9HYK96mWDS58V; Ml67D0WGktTkqg5X: $views->getFileContent(__DIR__ . "\x2f\166\151\x65\x77\163\x2f\64\60\63\56\x70\x68\160"); goto ApWZPPA43u6PsxBP; K0BnvDsopkwYMGk4: session_write_close(); goto I7LtTxbQ0AsmNpm6; M0CRM5wVEMLhmJNS: if (is_admin()) { goto w84TDwH64BzWpYfG; } goto K0BnvDsopkwYMGk4; I7LtTxbQ0AsmNpm6: $views = new \GDPlayer\Views(); goto Ml67D0WGktTkqg5X; RmE9HYK96mWDS58V: w84TDwH64BzWpYfG:
