<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:22              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto vJ0fMWAyETpNa7j3; jMC3HmBmzMyxmQo8: set_env("\x64\145\x73\143\x72\x69\160\x74\x69\x6f\156", "\124\150\x65\163\145\40\143\x68\x61\x6e\x67\145\x20\154\x6f\x67\163\40\151\156\x64\x69\x63\x61\x74\x65\40\164\x68\141\164\x20\164\x68\x69\x73\x20\167\145\142\163\x69\164\145\40\151\x73\40\x62\x65\x69\156\147\40\x6b\x65\x70\164\40\x75\160\40\164\157\x20\144\x61\164\145\x2e"); goto i4lnfG3lAELvZkQP; i4lnfG3lAELvZkQP: get_frontend_header(); goto y1V7XLM15RN9LWDY; N6_cf8RUFOfHz276: set_env("\164\x69\x74\154\x65", "\x43\x68\x61\156\147\145\x20\114\157\x67"); goto jMC3HmBmzMyxmQo8; vJ0fMWAyETpNa7j3: session_write_close(); goto N6_cf8RUFOfHz276; C3KuXjS5IH510koG: echo $html->renderTemplate("\x63\150\x61\x6e\147\145\x6c\x6f\x67\56\x68\x74\155\x6c\56\x74\167\151\x67", ["\x74\x69\164\154\x65" => "\x43\x68\x61\156\147\145\x20\114\157\x67", "\x64\145\x73\143" => "\103\150\141\156\x67\x65\x20\x4c\x6f\147\56"]); goto X6cUpMTdTvRpgMQD; y1V7XLM15RN9LWDY: $html = new \GDPlayer\HTML(); goto C3KuXjS5IH510koG; X6cUpMTdTvRpgMQD: get_frontend_footer();
