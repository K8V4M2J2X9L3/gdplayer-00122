<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:22              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto ydVNbeR2iizdSOH0; Ridoz37ZHiFMgckA: $player = new \GDPlayer\Player(); goto dZBmxM4J06HSR5xS; ydVNbeR2iizdSOH0: session_write_close(); goto ObonXoJQKoiGEIi0; ObonXoJQKoiGEIi0: $headers = corsResponseHeaders(true); goto KzhPxvO2ZeNRizee; RQrdlEyofDmf9r6E: createResponseHeaders($headers); goto Ridoz37ZHiFMgckA; KzhPxvO2ZeNRizee: $headers[] = "\x43\x61\143\150\145\55\x43\x6f\156\x74\x72\157\154\x3a\x20\156\x6f\55\143\141\x63\150\x65"; goto RQrdlEyofDmf9r6E; dZBmxM4J06HSR5xS: echo gzipResponse($player->getEmbedPage());
