<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:18              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto HHFQ9F9t0u1JkgIk; j3OOFQnXI149UKsw: $html = new \GDPlayer\HTML(); goto LF1T6dNQWQbz8kgV; UkVtjKo7rO_8kzkp: http_response_code(503); goto j3OOFQnXI149UKsw; HHFQ9F9t0u1JkgIk: session_write_close(); goto UkVtjKo7rO_8kzkp; LF1T6dNQWQbz8kgV: echo $html->renderTemplate("\144\145\146\x61\165\x6c\x74\56\150\x74\x6d\x6c\56\164\x77\x69\x67", ["\x74\x69\164\154\x65" => "\x35\x30\x33\x20\123\145\162\x76\x69\143\145\40\x55\x6e\141\x76\x61\151\154\x61\x62\x6c\x65", "\144\145\x73\x63" => "\x53\157\162\x72\171\x2c\x20\164\x68\145\40\x73\145\x72\x76\145\162\40\x69\x73\x20\143\x75\x72\x72\x65\156\164\x6c\171\x20\x75\156\x61\x76\141\x69\154\141\142\x6c\145\56\40\120\x6c\145\x61\163\145\x20\164\162\x79\40\x61\x67\x61\x69\x6e\40\x6c\x61\164\x65\162\x2e"]);
