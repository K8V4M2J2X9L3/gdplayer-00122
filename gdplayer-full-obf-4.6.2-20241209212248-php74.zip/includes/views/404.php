<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:18              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto gDkYbJCMF6H_vsB0; rbhrNQ5OASXZS5On: http_response_code(404); goto PKOwSH6Wiz9F5mOJ; gDkYbJCMF6H_vsB0: session_write_close(); goto rbhrNQ5OASXZS5On; PKOwSH6Wiz9F5mOJ: $html = new \GDPlayer\HTML(); goto aNMGiwACZDTEjQIc; aNMGiwACZDTEjQIc: echo $html->renderTemplate("\144\145\146\141\165\x6c\x74\x2e\x68\x74\x6d\154\x2e\x74\x77\x69\147", ["\x74\151\x74\x6c\145" => "\x34\60\64\40\120\141\147\145\40\x4e\157\164\40\106\x6f\x75\x6e\144", "\144\x65\163\x63" => "\124\x68\145\x20\x70\x61\x67\x65\40\x79\x6f\x75\x20\x61\x72\x65\40\154\157\157\x6b\151\156\x67\x20\x66\x6f\x72\40\167\x61\163\x20\156\157\x74\x20\x66\157\x75\156\144\x2e"]);
