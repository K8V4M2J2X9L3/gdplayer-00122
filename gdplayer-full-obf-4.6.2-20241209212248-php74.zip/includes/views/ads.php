<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto CWnTby0L__gko6lT; Ygqg2AXQq2e88pal: header("\103\157\x6e\x74\x65\156\164\55\x54\171\x70\145\x3a\40\x69\x6d\x61\x67\145\57\x70\x6e\x67", true); goto u2bGEoosOiGYBkrH; CWnTby0L__gko6lT: session_write_close(); goto CpfoGdm6kfOFkrF1; u2bGEoosOiGYBkrH: header("\103\x6f\x6e\164\145\156\x74\55\x4c\145\x6e\x67\164\150\72\40" . filesize($file), true); goto ti3qPKYGgoksXJG4; CpfoGdm6kfOFkrF1: $file = BASE_DIR . "\141\163\x73\x65\x74\163\x2f\151\155\x67\57\155\x61\x73\x6b\141\142\x6c\145\x5f\x69\x63\x6f\x6e\56\x70\156\147"; goto KhV7bdrwu3oZ298k; KhV7bdrwu3oZ298k: header("\103\141\x63\x68\x65\55\x43\x6f\156\164\x72\157\154\72\x20\156\157\x2d\143\x61\x63\x68\x65\x2c\40\x6e\157\55\x73\164\x6f\162\145\54\x20\x6d\x75\x73\x74\55\162\145\166\141\x6c\x69\x64\x61\164\x65", true); goto Ygqg2AXQq2e88pal; ti3qPKYGgoksXJG4: echo getFileContent($file, "\x72\x62");
