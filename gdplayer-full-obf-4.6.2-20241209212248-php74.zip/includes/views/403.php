<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:18              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto NbCyfHeYYApnm4hZ; OW7LMU8X53aF9y5v: http_response_code(403); goto fL0ayYtY12DHSp3i; NbCyfHeYYApnm4hZ: session_write_close(); goto OW7LMU8X53aF9y5v; fL0ayYtY12DHSp3i: $html = new \GDPlayer\HTML(); goto acYGfP8BwnpOwL2y; acYGfP8BwnpOwL2y: echo $html->renderTemplate("\144\x65\x66\x61\165\154\x74\x2e\x68\x74\155\x6c\x2e\x74\x77\x69\147", ["\164\151\x74\154\x65" => "\x34\60\63\x20\x46\157\x72\x62\151\144\144\x65\x6e", "\x64\x65\163\143" => "\131\157\165\40\x61\x72\145\40\x6e\x6f\164\x20\x61\x6c\154\x6f\x77\145\x64\x20\164\157\40\x61\143\x63\x65\x73\x73\40\x74\150\145\x20\160\141\147\145\56"]);
