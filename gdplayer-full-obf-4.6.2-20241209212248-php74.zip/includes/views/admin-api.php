<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto sow4W9dvWmWVrSwR; Crc3n9c7hIh8iClq: if (isset($_POST["\x61\143\x74\x69\157\156"])) { goto TOIdiQ4Xr5Li980o; } goto mN8HY_GjXWXiCMDi; mN8HY_GjXWXiCMDi: session_write_close(); goto X1mffFsN_73DXIy4; m9RNWoqeWO7v2kpo: echo $class->response($_POST); goto hY3qg3i0QekQMmJp; sow4W9dvWmWVrSwR: session_write_close(); goto I4ip7SsWiJVtolIW; X1mffFsN_73DXIy4: echo $class->notValid(); goto qdtt_yJzoCh7LHlV; aoyauc7i9v0mp5Gw: session_write_close(); goto m9RNWoqeWO7v2kpo; EwdIL7wF8dBLN7tE: $class = new \GDPlayer\Ajax\PrivateAjax(); goto Crc3n9c7hIh8iClq; I4ip7SsWiJVtolIW: createResponseHeaders(corsResponseHeaders()); goto NuBg2T2zpvk1uYQ6; NuBg2T2zpvk1uYQ6: header("\x43\141\x63\150\145\x2d\103\x6f\156\164\x72\x6f\x6c\72\x20\156\x6f\55\x63\141\143\x68\145\x2c\40\156\157\x2d\x73\164\157\162\x65\54\x20\x6d\x75\x73\164\x2d\162\145\x76\x61\x6c\151\144\141\x74\145", true); goto EwdIL7wF8dBLN7tE; zyWqvR1fO1MSKpKS: TOIdiQ4Xr5Li980o: goto aoyauc7i9v0mp5Gw; qdtt_yJzoCh7LHlV: goto SHTkzNGNIUXbJMeC; goto zyWqvR1fO1MSKpKS; hY3qg3i0QekQMmJp: SHTkzNGNIUXbJMeC:
