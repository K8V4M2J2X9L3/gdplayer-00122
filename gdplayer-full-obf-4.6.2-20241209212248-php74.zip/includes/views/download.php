<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:22              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto u2DaAHqnEQB2tlRF; vtNSMkZJK_wUHXfE: $headers = corsResponseHeaders(); goto I1JarFBOcRk0tgeY; Ca6sX_E3XaeImlZ0: createResponseHeaders($headers); goto pNtEDofXPAFTzkHK; u2DaAHqnEQB2tlRF: session_write_close(); goto vtNSMkZJK_wUHXfE; I1JarFBOcRk0tgeY: $headers[] = "\x43\141\x63\150\x65\x2d\x43\x6f\156\164\x72\x6f\154\72\x20\156\157\x2d\143\x61\x63\150\145"; goto Ca6sX_E3XaeImlZ0; pNtEDofXPAFTzkHK: $player = new \GDPlayer\Player(true); goto wsoUBCDDstjj2_rM; wsoUBCDDstjj2_rM: echo gzipResponse($player->getDownloadPage());
