<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:18              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto EpG1aTmMtyXlNt3z; wp3j0DiWd8R4erJM: $html = new \GDPlayer\HTML(); goto cF_nuUQvYbldYLK1; EpG1aTmMtyXlNt3z: session_write_close(); goto o8jbibnNaL4996j9; o8jbibnNaL4996j9: http_response_code(401); goto wp3j0DiWd8R4erJM; cF_nuUQvYbldYLK1: echo $html->renderTemplate("\144\145\146\141\x75\154\164\x2e\x68\164\x6d\154\56\x74\x77\x69\147", ["\164\151\x74\154\145" => "\64\x30\61\40\x55\156\141\165\164\x68\157\162\x69\x7a\145\144", "\144\x65\163\x63" => "\124\150\x65\x20\x70\x61\147\x65\40\x73\x68\157\x75\x6c\x64\x20\157\156\x6c\171\40\x62\x65\40\x61\143\x63\x65\x73\x73\x65\144\40\x62\x79\x20\162\145\x67\151\x73\x74\x65\x72\145\x64\40\x75\x73\145\162\163\56"]);
