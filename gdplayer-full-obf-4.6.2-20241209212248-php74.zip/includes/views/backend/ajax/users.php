<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto qHXDi5LHeAPva9w7; qHXDi5LHeAPva9w7: session_write_close(); goto zgxkw93yIwkroT02; zgxkw93yIwkroT02: $class = new \GDPlayer\Ajax\User(); goto qKXsh9Htkx6BEgeR; qKXsh9Htkx6BEgeR: echo $class->response($_POST);
