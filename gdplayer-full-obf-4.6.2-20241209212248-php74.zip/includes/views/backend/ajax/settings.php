<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto yeV13vCh3rmZXXd3; lFseB4kcsZdoDYUB: $class = new \GDPlayer\Ajax\Setting(); goto MDKd3rkJbvBG6MBI; yeV13vCh3rmZXXd3: session_write_close(); goto lFseB4kcsZdoDYUB; MDKd3rkJbvBG6MBI: echo $class->response($_POST);
