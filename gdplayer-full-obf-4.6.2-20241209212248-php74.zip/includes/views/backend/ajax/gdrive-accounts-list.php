<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto mn_7mug6BK4CbSA8; gTZs9zQbPfPvjgrj: $class = new \GDPlayer\Ajax\GDriveAccount(); goto m8eUT5oGgibYqGRs; mn_7mug6BK4CbSA8: session_write_close(); goto gTZs9zQbPfPvjgrj; m8eUT5oGgibYqGRs: echo $class->list($_GET);
