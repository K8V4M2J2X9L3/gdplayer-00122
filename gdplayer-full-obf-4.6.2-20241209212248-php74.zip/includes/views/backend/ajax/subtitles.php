<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto R3Dj2dhmqgEzwx7r; BhMSJQ0sY8LfIMlg: $class = new \GDPlayer\Ajax\Subtitle(); goto Kye3Q2CsjnWIxEnV; R3Dj2dhmqgEzwx7r: session_write_close(); goto BhMSJQ0sY8LfIMlg; Kye3Q2CsjnWIxEnV: echo $class->response($_POST, $_FILES);
