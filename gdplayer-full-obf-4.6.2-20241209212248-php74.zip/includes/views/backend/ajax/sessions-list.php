<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto Byid3YL_6UI9wBrs; Byid3YL_6UI9wBrs: session_write_close(); goto cogbGNheUHXYBB3N; cogbGNheUHXYBB3N: $class = new \GDPlayer\Ajax\Session(); goto knF1lRy35gCCicGi; knF1lRy35gCCicGi: echo $class->list($_GET);
