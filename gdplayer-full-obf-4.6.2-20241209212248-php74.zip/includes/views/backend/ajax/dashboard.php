<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto vfAax7vA1dxJT86a; vfAax7vA1dxJT86a: session_write_close(); goto sGAnw7gUPsHGk1UE; sGAnw7gUPsHGk1UE: $class = new \GDPlayer\Ajax\Dashboard(); goto BVCFafgFsQcEiXx_; BVCFafgFsQcEiXx_: echo $class->response($_POST);
