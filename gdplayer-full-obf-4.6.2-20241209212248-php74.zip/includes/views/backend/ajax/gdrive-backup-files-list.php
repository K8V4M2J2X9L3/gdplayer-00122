<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto rKwJSPYXEbRaskzy; BXDpD87v2bh89rVj: $class = new \GDPlayer\Ajax\GDriveMirror(); goto lQENT7psoq2XMzdp; rKwJSPYXEbRaskzy: session_write_close(); goto BXDpD87v2bh89rVj; lQENT7psoq2XMzdp: echo $class->list($_GET);
