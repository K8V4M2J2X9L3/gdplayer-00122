<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto i8NspxlJ0EWtt1Ox; Q_TMGuvqUnnHNGy1: $class = new \GDPlayer\Ajax\User(); goto vj32vnIbkOS9YL9a; i8NspxlJ0EWtt1Ox: session_write_close(); goto Q_TMGuvqUnnHNGy1; vj32vnIbkOS9YL9a: echo $class->list($_GET);
