<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto pQx9FF5xnP0MPhAh; pQx9FF5xnP0MPhAh: session_write_close(); goto I_7_PUC8xiRyk6LX; I_7_PUC8xiRyk6LX: $class = new \GDPlayer\Ajax\GDriveFile(); goto xgv8XlHciCWXMfyo; xgv8XlHciCWXMfyo: echo $class->list($_GET);
