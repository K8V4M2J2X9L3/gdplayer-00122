<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto nW8wY4mbhyYZOBed; LVLeOGQP2KS2cM6Y: $class = new \GDPlayer\Ajax\Session(); goto KiP99oH0EdP2VHKG; nW8wY4mbhyYZOBed: session_write_close(); goto LVLeOGQP2KS2cM6Y; KiP99oH0EdP2VHKG: echo $class->response($_POST);
