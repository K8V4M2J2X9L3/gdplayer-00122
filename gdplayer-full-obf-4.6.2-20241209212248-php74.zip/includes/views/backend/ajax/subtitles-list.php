<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto dx35034XlO5zjMLw; dx35034XlO5zjMLw: session_write_close(); goto q8azlQR1UqbvtonR; q8azlQR1UqbvtonR: $class = new \GDPlayer\Ajax\Subtitle(); goto zYXnJqree5zSk_tz; zYXnJqree5zSk_tz: echo $class->list($_GET);
