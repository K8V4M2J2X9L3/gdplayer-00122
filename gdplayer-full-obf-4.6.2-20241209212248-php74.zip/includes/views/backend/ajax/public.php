<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto g0Fa0maaUSQpBUiS; iHO5587zO2TG_puD: $class = new \GDPlayer\Ajax\PublicAjax(); goto PNwiMbMOefe9JLTJ; g0Fa0maaUSQpBUiS: session_write_close(); goto iHO5587zO2TG_puD; PNwiMbMOefe9JLTJ: echo $class->response($_POST);
