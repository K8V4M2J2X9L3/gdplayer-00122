<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto ZoTuw64LqnU9aBg_; tkF5ehUGuwkFLkNG: $class = new \GDPlayer\Ajax\GDriveMirror(); goto s_Zl0KQyR4XEcEjC; ZoTuw64LqnU9aBg_: session_write_close(); goto tkF5ehUGuwkFLkNG; s_Zl0KQyR4XEcEjC: echo $class->response($_POST);
