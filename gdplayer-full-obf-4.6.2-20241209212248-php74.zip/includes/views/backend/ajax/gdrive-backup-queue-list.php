<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto fA41WS954LEXBv76; fA41WS954LEXBv76: session_write_close(); goto a66xj7gt_QsGcBOd; a66xj7gt_QsGcBOd: $class = new \GDPlayer\Ajax\GDriveQueue(); goto dU1mXFpz4Zghhg0g; dU1mXFpz4Zghhg0g: echo $class->list($_GET);
