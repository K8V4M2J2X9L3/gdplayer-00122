<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto izHHNYlT6NN2cT1F; xLSJ_5VPmQZC0qPb: $class = new \GDPlayer\Ajax\GDriveAccount(); goto yHyH1KGmVrsJgL6V; izHHNYlT6NN2cT1F: session_write_close(); goto xLSJ_5VPmQZC0qPb; yHyH1KGmVrsJgL6V: echo $class->response($_POST);
