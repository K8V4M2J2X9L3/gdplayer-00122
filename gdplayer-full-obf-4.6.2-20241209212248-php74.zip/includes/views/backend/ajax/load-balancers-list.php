<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto TD0Q4uhbusvRhvWB; mXCnGh7r7391Rfl0: $class = new \GDPlayer\Ajax\LoadBalancer(); goto NxTXm0T5b3c8mhdU; TD0Q4uhbusvRhvWB: session_write_close(); goto mXCnGh7r7391Rfl0; NxTXm0T5b3c8mhdU: echo $class->list($_GET);
