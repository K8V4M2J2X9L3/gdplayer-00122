<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto b1vD0JioB02FgxEs; b1vD0JioB02FgxEs: session_write_close(); goto AOzB0twMM40Jn5wO; AOzB0twMM40Jn5wO: $class = new \GDPlayer\Ajax\User(); goto m5l9uCMChZYZQ1tP; m5l9uCMChZYZQ1tP: echo $class->response($_POST);
