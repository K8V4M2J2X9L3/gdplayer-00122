<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto STZHcjVYCyWLTg7U; STZHcjVYCyWLTg7U: session_write_close(); goto azPw2LqIh9YgWtR4; azPw2LqIh9YgWtR4: $class = new \GDPlayer\Ajax\GDriveFile(); goto dS7Xl6EwlN_nv16v; dS7Xl6EwlN_nv16v: echo $class->response($_POST);
