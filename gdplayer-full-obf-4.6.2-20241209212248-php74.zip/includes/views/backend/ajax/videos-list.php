<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto cimfExol2ooxcqel; ku1T1CCzA3H1Wrqx: $class = new \GDPlayer\Ajax\Video(); goto nlgmznGbwy9INkho; cimfExol2ooxcqel: session_write_close(); goto ku1T1CCzA3H1Wrqx; nlgmznGbwy9INkho: echo $class->list($_GET);
