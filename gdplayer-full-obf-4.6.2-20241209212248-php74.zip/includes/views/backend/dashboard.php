<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto Q2PvGABHH3CXjUlf; Q2PvGABHH3CXjUlf: session_write_close(); goto B9EUjwW37rVM3rD6; IhkzqhoSl6BAIel6: $iCache = new \GDPlayer\InstanceCache(); goto aCE78iSdFvzw45DU; aCE78iSdFvzw45DU: $server = new \GDPlayer\ServerInfo(); goto fsBXIyKRGpHktHRL; B9EUjwW37rVM3rD6: include_once BASE_DIR . "\151\156\143\x6c\x75\x64\x65\163\57\x69\x73\125\x73\145\162\56\x70\150\x70"; goto AmxQHX3JjhatzCqh; Qhfu006KXGWoem3i: get_backend_header(); goto IhkzqhoSl6BAIel6; fsBXIyKRGpHktHRL: $class = new \GDPlayer\HTML(); goto EwEptAjUrz30VLhp; EwEptAjUrz30VLhp: echo $class->renderTemplate("\x64\141\163\150\142\157\x61\x72\x64\56\150\x74\155\x6c\56\164\167\x69\x67", ["\164\x69\x74\154\x65" => get_env("\x74\x69\x74\154\x65"), "\x61\144\x6d\151\156\137\x64\x69\x72" => ADMIN_DIR, "\x69\163\x5f\141\144\155\151\x6e" => is_admin(), "\150\151\x64\145\x5f\145\170\x74\x5f\144\151\141\x6c\x6f\147" => $iCache->get("\150\151\144\x65\x5f\145\170\x74\x5f\144\151\141\154\157\147") ?? false]); goto UZ48M6PPyxIfufPn; AmxQHX3JjhatzCqh: set_env("\164\151\x74\154\145", "\104\x61\163\x68\142\x6f\141\x72\144"); goto Qhfu006KXGWoem3i; UZ48M6PPyxIfufPn: get_backend_footer();
