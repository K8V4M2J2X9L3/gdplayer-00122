<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:21              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto vRv5j71YCE5CQhTJ; MwDAuNvnKmGoMKK2: get_backend_header(); goto ufcb5VhKYpSageag; vRv5j71YCE5CQhTJ: session_write_close(); goto LeYW6N99xM_dc6mq; AD2X7A0Z1gmZVzP9: set_env("\x74\151\x74\154\145", "\x53\x65\163\x73\151\x6f\156\x20\x4c\x69\163\x74"); goto MwDAuNvnKmGoMKK2; LeYW6N99xM_dc6mq: include_once BASE_DIR . "\151\x6e\143\154\165\x64\145\163\57\x69\163\x41\144\x6d\151\156\x2e\160\150\160"; goto AD2X7A0Z1gmZVzP9; ufcb5VhKYpSageag: $html = new \GDPlayer\HTML(); goto U2IFNZL2D_ZmPq6u; U2IFNZL2D_ZmPq6u: echo $html->renderTemplate("\x75\x73\145\162\163\x2f\163\x65\x73\163\151\157\156\55\x6c\x69\163\x74\56\150\164\x6d\154\56\164\167\151\147", ["\164\151\x74\154\145" => get_env("\164\x69\164\154\145"), "\141\144\x6d\151\x6e\x5f\144\151\x72" => ADMIN_DIR]); goto xP1GVarkHKxdXcs5; xP1GVarkHKxdXcs5: get_backend_footer();
