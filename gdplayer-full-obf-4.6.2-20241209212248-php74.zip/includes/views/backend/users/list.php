<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:21              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto uxwQp5IzaxckpXu4; UUKBH4U1AbPm_PMi: get_backend_header(); goto AQD8CxnwzmER5arL; sec_AOE7lIiRjpbO: include_once BASE_DIR . "\151\156\x63\154\x75\144\145\163\57\151\163\x41\x64\155\151\x6e\x2e\160\x68\x70"; goto FIgqJoz37KPaESP2; UQUQdJ_cAtaaEDZS: echo $html->renderTemplate("\165\163\x65\x72\x73\x2f\x6c\151\x73\164\56\150\x74\155\x6c\56\x74\167\151\x67", ["\164\x69\x74\x6c\145" => get_env("\164\151\x74\x6c\145"), "\141\x64\x6d\151\156\137\144\151\x72" => ADMIN_DIR]); goto Mr8Nb51yd976DD7d; FIgqJoz37KPaESP2: set_env("\x74\151\x74\154\145", "\x55\163\x65\162\40\x4c\151\x73\164"); goto UUKBH4U1AbPm_PMi; uxwQp5IzaxckpXu4: session_write_close(); goto sec_AOE7lIiRjpbO; AQD8CxnwzmER5arL: $html = new \GDPlayer\HTML(); goto UQUQdJ_cAtaaEDZS; Mr8Nb51yd976DD7d: get_backend_footer();
