<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto RXS9l6G3HPqS8j32; nPUTSOLXJ8PbQe5J: echo $html->renderTemplate("\x67\144\x72\151\166\145\x2f\x61\143\x63\x6f\165\x6e\164\55\154\151\163\164\x2e\150\164\x6d\154\56\164\167\151\147", ["\164\151\164\154\145" => get_env("\164\x69\x74\154\x65"), "\x61\144\155\x69\156\x5f\144\x69\162" => ADMIN_DIR]); goto HJ0qDvcZJgwrVAAv; do33uVHnrtCddCYu: get_backend_header(); goto EHvfq0aIDVepkPqi; RXS9l6G3HPqS8j32: session_write_close(); goto bF8U42MyAIinIVQT; EHvfq0aIDVepkPqi: $html = new \GDPlayer\HTML(); goto nPUTSOLXJ8PbQe5J; bhiK_FT6CUg1aKkQ: set_env("\x74\x69\x74\x6c\x65", "\x47\157\157\147\154\x65\40\x44\x72\x69\x76\145\40\101\143\143\x6f\x75\x6e\164\163"); goto do33uVHnrtCddCYu; bF8U42MyAIinIVQT: include_once BASE_DIR . "\x69\x6e\143\154\165\144\x65\x73\x2f\x69\x73\101\144\155\151\156\x2e\x70\150\x70"; goto bhiK_FT6CUg1aKkQ; HJ0qDvcZJgwrVAAv: get_backend_footer();
