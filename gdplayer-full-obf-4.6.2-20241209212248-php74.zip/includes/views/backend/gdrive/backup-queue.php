<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto h91gQoZ1yWPHl3IJ; NSAg3VeJgdrgqfid: set_env("\164\151\x74\154\145", "\107\157\157\x67\x6c\145\40\104\162\x69\166\x65\40\102\141\x63\153\165\x70\40\x51\165\145\165\x65\40\114\151\163\x74"); goto EPStR2VstlosGw3o; zMhcMGU52pK0H1eE: $html = new \GDPlayer\HTML(); goto clGaKWHGtLqOu191; EPStR2VstlosGw3o: get_backend_header(); goto zMhcMGU52pK0H1eE; xDlYberrVTSx8ac3: include_once BASE_DIR . "\x69\x6e\143\154\x75\x64\x65\x73\57\x69\x73\x41\144\155\x69\156\x2e\160\150\160"; goto NSAg3VeJgdrgqfid; clGaKWHGtLqOu191: echo $html->renderTemplate("\x67\144\162\x69\x76\145\x2f\142\141\143\x6b\165\x70\x2d\161\165\x65\165\x65\x2e\150\x74\155\154\56\x74\167\x69\147", ["\x74\151\164\x6c\x65" => get_env("\164\151\x74\154\x65")]); goto zFMCnd0CVaXCkJvP; h91gQoZ1yWPHl3IJ: session_write_close(); goto xDlYberrVTSx8ac3; zFMCnd0CVaXCkJvP: get_backend_footer();
