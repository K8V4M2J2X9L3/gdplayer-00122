<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto VIGDk1Ajwp2DfSpz; gPKDZMK9QtOxycRA: include_once BASE_DIR . "\x69\x6e\143\154\x75\x64\x65\163\x2f\x69\x73\x41\144\155\151\156\x2e\160\150\160"; goto oQ3v0SHHm4G6DX3C; VIGDk1Ajwp2DfSpz: session_write_close(); goto gPKDZMK9QtOxycRA; KPipHN10eM_esL0D: echo $html->renderTemplate("\x67\144\162\x69\166\145\57\x62\141\143\x6b\165\160\x2d\146\x69\154\145\163\x2e\x68\x74\155\x6c\x2e\164\x77\x69\147", ["\164\x69\164\154\x65" => get_env("\x74\x69\x74\x6c\145")]); goto qD8Rg8I4VTE__5V0; gE4kZoa9c4ETGgLQ: $html = new \GDPlayer\HTML(); goto KPipHN10eM_esL0D; uUnAXgxB2VwcoWXq: get_backend_header(); goto gE4kZoa9c4ETGgLQ; oQ3v0SHHm4G6DX3C: set_env("\164\x69\164\154\145", "\107\157\157\147\154\145\x20\104\162\151\x76\x65\40\102\141\x63\x6b\x75\160\x20\x46\151\154\x65\40\x4c\x69\163\164"); goto uUnAXgxB2VwcoWXq; qD8Rg8I4VTE__5V0: get_backend_footer();
