<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:21              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto jispqiNZ0V1SLevn; GImOSZQRY08CqjNE: $html = new \GDPlayer\HTML(); goto R8FLinxsX_lcFXZl; R8FLinxsX_lcFXZl: echo $html->renderTemplate("\x76\x69\x64\145\x6f\x73\x2f\163\x75\142\164\151\164\154\145\x2d\x6c\151\163\x74\x2e\150\164\155\x6c\x2e\164\167\151\x67", ["\164\x69\x74\154\x65" => get_env("\164\151\164\x6c\x65"), "\151\163\137\141\144\155\151\x6e" => is_admin(), "\163\x75\142\164\151\164\154\145\x73" => $subtitles, "\142\141\x73\145\x5f\x75\x72\154" => BASE_URL]); goto IiQqwC9il2IPajjd; UzgoxQ4nt_165Jx9: $subtitles = array_values($subtitles); goto VRfzaaEFgD0D7Oy6; zF2fZk4MCmZ8_jCO: $subtitles = language_list(); goto UzgoxQ4nt_165Jx9; tLQXkDM9C6M5HmBg: include_once BASE_DIR . "\151\x6e\143\154\165\x64\x65\x73\x2f\151\163\125\x73\145\162\x2e\160\x68\160"; goto zF2fZk4MCmZ8_jCO; jispqiNZ0V1SLevn: session_write_close(); goto tLQXkDM9C6M5HmBg; gt41RqDFRBJ5PPru: get_backend_header(); goto GImOSZQRY08CqjNE; VRfzaaEFgD0D7Oy6: set_env("\x74\x69\164\x6c\145", "\123\165\x62\164\151\x74\x6c\145\x20\115\x61\x6e\x61\x67\x65\x72"); goto gt41RqDFRBJ5PPru; IiQqwC9il2IPajjd: get_backend_footer();
