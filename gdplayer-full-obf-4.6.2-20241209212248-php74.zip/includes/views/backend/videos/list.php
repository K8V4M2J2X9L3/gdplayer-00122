<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:21              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto kSj2LmBZj1wyvVdE; o4FrclO2WlCegvxy: echo $html->renderTemplate("\166\151\x64\x65\x6f\x73\57\x6c\x69\x73\164\56\150\x74\x6d\x6c\56\164\x77\151\147", ["\x74\x69\164\154\x65" => get_env("\164\151\x74\x6c\145"), "\142\x61\163\x65\x5f\x75\x72\154" => BASE_URL, "\141\144\x6d\x69\156\137\x64\x69\x72" => ADMIN_DIR, "\151\x73\137\141\x64\x6d\x69\x6e" => is_admin(), "\163\x75\160\x70\x6f\x72\x74\x65\144\137\163\151\x74\x65\x73" => $supportedSites, "\151\x6d\160\157\x72\164\x5f\146\151\x6c\145\x73\x69\x7a\x65" => intval(get_option("\x69\x6d\x70\x6f\x72\x74\137\x66\x69\154\x65\x73\x69\172\x65") ?? 1024)]); goto px0BBVffIUqzgd9z; kSj2LmBZj1wyvVdE: session_write_close(); goto v8M8Zkm0xNgqWcuS; v8M8Zkm0xNgqWcuS: include_once BASE_DIR . "\x69\x6e\x63\154\165\x64\x65\x73\x2f\x69\x73\125\163\x65\162\56\160\150\160"; goto Rnyxqvh7x14MVC5T; Rnyxqvh7x14MVC5T: set_env("\164\x69\x74\x6c\145", "\126\x69\x64\145\x6f\x20\114\x69\x73\x74"); goto kWK6xasbaGrP6Iho; mHlbKyzXWvjj4EEZ: ksort($supportedSites, SORT_NATURAL); goto o9n5ZDN5nTOk3kOF; kWK6xasbaGrP6Iho: get_backend_header(); goto DZs4UFmZnLgQ2Ya2; DZs4UFmZnLgQ2Ya2: $supportedSites = supportedSites(); goto mHlbKyzXWvjj4EEZ; o9n5ZDN5nTOk3kOF: $html = new \GDPlayer\HTML(); goto o4FrclO2WlCegvxy; px0BBVffIUqzgd9z: get_backend_footer();
