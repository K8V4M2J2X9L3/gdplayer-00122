<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto xv4QKUR3xmJ4kYUN; sYbAMM7q46s6BW_6: include_once BASE_DIR . "\x69\x6e\143\154\165\144\145\163\57\x69\163\101\x64\155\x69\156\x2e\160\x68\160"; goto Phko5HPpjES_FLNm; L3wcvRqCjgZK9hcX: get_backend_header(); goto gYvAfe1XvcPw_3u9; eofaG2vCC_ZMS98a: echo $html->renderTemplate("\154\157\141\x64\55\x62\141\x6c\x61\156\143\x65\162\x73\x2f\x6c\x69\x73\x74\x2e\x68\x74\x6d\154\56\x74\167\x69\147", ["\164\x69\x74\154\x65" => get_env("\164\x69\x74\x6c\x65"), "\141\x64\x6d\151\156\x5f\x64\x69\162" => ADMIN_DIR]); goto lOEjT0uBQID1xhj5; Phko5HPpjES_FLNm: set_env("\164\x69\164\x6c\145", "\x4c\157\x61\144\x20\x42\x61\154\141\x6e\143\x65\x72\40\x53\145\162\x76\x65\162\163"); goto L3wcvRqCjgZK9hcX; gYvAfe1XvcPw_3u9: $html = new \GDPlayer\HTML(); goto eofaG2vCC_ZMS98a; xv4QKUR3xmJ4kYUN: session_write_close(); goto sYbAMM7q46s6BW_6; lOEjT0uBQID1xhj5: get_backend_footer();
