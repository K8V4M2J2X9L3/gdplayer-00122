<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:21              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto XliPb6oUAtQOLmIe; AZq8dsV_xMGlbKIU: include_once BASE_DIR . "\151\x6e\x63\154\x75\x64\145\x73\x2f\x73\145\x74\164\x69\x6e\x67\163\x2e\160\x68\160"; goto m0zxQux8wQK4zdb1; XliPb6oUAtQOLmIe: session_write_close(); goto AZq8dsV_xMGlbKIU; ji93B58e4sR63wXF: get_backend_header(); goto P7fwudKVkbzL0Ihd; x9vpJNI2Q1t2XIMe: echo $html->renderForm("\x73\x65\164\164\151\x6e\147\x73\x2d\x77\x72\x61\x70\160\145\x72\x2e\150\164\155\x6c\x2e\x74\x77\151\x67", ["\x72\x65\x73\x65\x74\137\146\x6f\162\155" => "\163\145\164\x74\151\156\147\163\57\162\x65\x73\145\x74\56\150\x74\155\x6c\56\x74\167\x69\147", "\x61\x64\155\151\x6e\x5f\x64\151\162" => ADMIN_DIR . "\57\x73\145\164\x74\x69\156\x67\163\57\x72\145\163\x65\164\57"]); goto VkzBal6Iv20WUwh6; P7fwudKVkbzL0Ihd: $html = new \GDPlayer\HTML(); goto x9vpJNI2Q1t2XIMe; m0zxQux8wQK4zdb1: set_env("\164\x69\164\x6c\145", "\122\145\x73\x65\164\x20\x53\145\x74\164\x69\x6e\147\x73"); goto ji93B58e4sR63wXF; VkzBal6Iv20WUwh6: get_backend_footer();
