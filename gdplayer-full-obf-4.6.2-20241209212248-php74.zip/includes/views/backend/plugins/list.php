<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto SbvMCZe6yFZP2bi7; PTmIqiPOH8utQO7s: get_backend_header(); goto CPgcBnPHjOhAt3lX; SNvzLstCTrKPGAUt: echo $html->renderTemplate("\x70\154\165\x67\151\156\55\154\x69\x73\x74\x2e\150\164\155\x6c\56\x74\167\x69\147", ["\164\151\164\x6c\x65" => get_env("\x74\x69\x74\154\x65")]); goto JRYB0OQyTkSC6t6Q; NRebVNIfX9fB0FYD: set_env("\164\x69\164\154\145", "\120\x6c\165\x67\x69\x6e\163\x20\114\x69\x73\164"); goto PTmIqiPOH8utQO7s; b6l52IDVA91Do3p8: include_once BASE_DIR . "\x69\x6e\x63\154\x75\144\x65\163\x2f\x69\163\101\144\155\x69\156\x2e\160\x68\x70"; goto NRebVNIfX9fB0FYD; CPgcBnPHjOhAt3lX: $html = new \GDPlayer\HTML(); goto SNvzLstCTrKPGAUt; SbvMCZe6yFZP2bi7: session_write_close(); goto b6l52IDVA91Do3p8; JRYB0OQyTkSC6t6Q: get_backend_footer();
