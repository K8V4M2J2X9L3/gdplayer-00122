<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.14  |
    |              on 2024-12-01 06:19:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
 goto o5qQA6j8CZOCmWll; o5qQA6j8CZOCmWll: session_write_close(); goto OzKtB3sMrvRJpJlv; zITk2xGMJj14knbR: echo "\x3c\x2f\x68\61\76\12\x20\40\x20\40\x20\x20\x20\x20\x3c\x68\63\40\143\x6c\141\163\x73\75\42\150\x34\x20\x74\x65\x78\164\x2d\163\x65\143\157\156\144\x61\x72\x79\x22\76\x53\x6f\x72\162\171\40\x74\150\x69\x73\40\x76\151\144\x65\x6f\x20\x69\x73\40\165\156\141\x76\141\x69\x6c\141\x62\x6c\145\56\x3c\x2f\150\63\x3e\12\x20\40\x20\x20\74\57\144\x69\166\x3e\12\x3c\x2f\x64\151\166\x3e\xa"; goto rrmqDmGAbkudX0XM; l5o5SqrpY1UpWnKP: echo "\x3c\x64\151\x76\x20\x63\x6c\x61\x73\163\75\x22\x72\157\167\x22\x3e\12\x20\x20\40\40\74\x64\x69\166\x20\x63\x6c\x61\x73\163\x3d\42\x63\157\x6c\55\x31\62\x20\164\145\170\x74\x2d\x63\145\x6e\x74\145\x72\x22\x3e\12\x20\40\40\x20\x20\40\x20\x20\x3c\x68\61\x20\143\154\x61\163\163\75\42\150\63\40\x74\145\x78\164\x2d\144\x61\156\147\145\162\42\76"; goto I28MvoQslpoDMZOs; I28MvoQslpoDMZOs: echo get_env("\164\x69\x74\154\145"); goto zITk2xGMJj14knbR; c2D1NPivw1l0bw3C: get_backend_header(); goto l5o5SqrpY1UpWnKP; OzKtB3sMrvRJpJlv: set_env("\x74\151\164\x6c\x65", "\104\x4d\x43\x41\x20\x54\x61\153\145\x64\x6f\x77\x6e"); goto c2D1NPivw1l0bw3C; rrmqDmGAbkudX0XM: get_backend_footer();
