<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}
$plugins = new \GDPlayer\Plugins();
$widget = new \GDPlayer\Widget();
echo $widget->loadCdnJsScript('pwacompat/2.0.17/pwacompat.min.js');
echo $widget->loadCdnJsScript('jqueryui/1.14.1/jquery-ui.min.js');
echo $widget->loadCdnJsScript('bootstrap/4.6.2/js/bootstrap.bundle.min.js');
echo $widget->loadCdnJsScript('js-cookie/3.0.5/js.cookie.min.js');
echo $widget->loadCdnJsScript('bootstrap-sweetalert/1.0.1/sweetalert.min.js');
echo $widget->loadCdnJsScript('toastify-js/1.12.0/toastify.min.js');
echo $widget->loadCdnJsScript('bs-custom-file-input/1.3.4/bs-custom-file-input.min.js');
echo $widget->loadCdnJsScript('select2/4.0.13/js/select2.min.js');
echo $widget->loadScript('assets/vendor/jquery-wheelcolorpicker/jquery.wheelcolorpicker.min.js');
echo $widget->loadCdnJsScript('apexcharts/4.1.0/apexcharts.min.js');
echo $widget->loadCdnJsScript('multi-select/0.9.12/js/jquery.multi-select.min.js');
echo $widget->loadScript(
    '//cdn.datatables.net/v/bs4/dt-1.13.2/fc-4.2.1/fh-3.3.1/r-2.4.0/rg-1.3.0/sr-1.2.1/datatables.min.js'
);
echo $widget->loadScript('assets/js/md5.js');
$jsExt = validate_boolean(get_option('production_mode')) ? 'min.js' : 'js';
echo $widget->loadScript(sprintf('assets/js/main-v%s.%s', JS_VERSION, $jsExt));

$script = $plugins->getBackendJS(true);
if ($script) {
    session_write_close();
    echo $script;
}
echo $widget->recaptcha();
echo $widget->histats();
echo htmlspecialchars_decode(get_option('chat_widget') ?? '', ENT_QUOTES);
echo $widget->default();
