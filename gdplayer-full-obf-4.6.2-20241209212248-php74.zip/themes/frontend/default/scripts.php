<?php
session_write_close();
if (!defined('BASE_DIR')) {
    session_write_close();
    exit('Access denied!');
}
$plugins = new \GDPlayer\Plugins();
$widget = new \GDPlayer\Widget();
echo $widget->loadCdnJsScript('pwacompat/2.0.17/pwacompat.min.js');
echo $widget->loadCdnJsScript('bootstrap/4.6.2/js/bootstrap.bundle.min.js');
echo $widget->loadCdnJsScript('select2/4.0.13/js/select2.min.js');
echo $widget->loadCdnJsScript('bootstrap-sweetalert/1.0.1/sweetalert.min.js');
echo $widget->loadCdnJsScript('bs-custom-file-input/1.3.4/bs-custom-file-input.min.js');
echo $widget->loadCdnJsScript('js-cookie/3.0.5/js.cookie.min.js');
$jsExt = validate_boolean(get_option('production_mode')) ? 'min.js' : 'js';
echo $widget->loadScript(sprintf('assets/js/main-v%s.%s', JS_VERSION, $jsExt));

$script = $plugins->getFrontendJS(true);
if ($script) {
    session_write_close();
    echo $script;
}
echo $widget->recaptcha();
echo $widget->sharer();
echo $widget->histats();
echo htmlspecialchars_decode(get_option('chat_widget') ?? '', ENT_QUOTES);
echo $widget->default();
